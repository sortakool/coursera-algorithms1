/**
 * Created by rmanaloto on 6/26/14.
 */
public class Percolation {

//    private enum State {
//        BLOCKED, OPEN, FULL;
//    }

    private static final int INVALID_INDEX = -1;

    private final int N;
    private final int cellCount;
    private final int size;
    private final WeightedQuickUnionUF unionFind;
    private boolean percolates = false;
    private final int topRow;
    private final int bottomRow;
    private final int leftColumn;
    private final int rightColumn;
    private final int virtualTop;
    //    private final int virtualBottom;
    private final boolean[] states;

//    private int percolationIndex = INVALID_INDEX;

    /**
     * create N-by-N grid, with all sites blocked
     *
     * @param N
     */
    public Percolation(int N) {
        if (N <= 0) {
            throw new IllegalArgumentException("Invalid grid dimension " + N);
        }
        this.N = N;
        this.cellCount = N * N;
        this.size = cellCount + 1;
        this.virtualTop = cellCount;
//        this.virtualBottom = cellCount + 1;
        unionFind = new WeightedQuickUnionUF(this.size);
        topRow = 1;
        bottomRow = N;
        leftColumn = 1;
        rightColumn = N;

        states = new boolean[cellCount];
//        Arrays.fill(states, State.BLOCKED);

        //connect top row to virtual top
        for (int i = 0; i < N; i++) {
            unionFind.union(virtualTop, i);
        }
//        for(int i=0; i<N; i++) {
//            final int root = weightedQuickUnionUF.find(i);
//            System.out.println("[i="+i+"][root="+root+"]");
//        }
//        //connect top row to virtual bottom
//        for (int i = (cellCount - N); i < cellCount; i++) {
//            weightedQuickUnionUF.union(virtualBottom, i);
//        }
//        for(int i=(cellCount-N); i<cellCount; i++) {
//            final int root = weightedQuickUnionUF.find(i);
//            System.out.println("[i="+i+"][root="+root+"]");
//        }
    }

    /**
     * open site (row i, column j) if it is not already
     *
     * @param i
     * @param j
     */
    public void open(int i, int j) {
        final int index = validateAndGetIndex(i, j);
        if (!states[index]) { //not open
            final int topIndex = getTopIndex(i, j);
            final int bottomIndex = getBottomIndex(i, j);
            final int leftIndex = getLeftIndex(i, j);
            final int rightIndex = getRightIndex(i, j);

            unionIndexes(topIndex, index);
            unionIndexes(bottomIndex, index);
            unionIndexes(leftIndex, index);
            unionIndexes(rightIndex, index);

            states[index] = true;

//                final boolean bottom = isBottom(i);
//                if (bottom) {
//                    final boolean connectedToVirtualTop =
//                            weightedQuickUnionUF.connected(index, virtualTop);
//                    if (connectedToVirtualTop) {
//                        percolates = true;
////                        System.out.println(
////                                "percolates: [i=" + i + "][j=" + j + "]");
////                        percolationIndex = index;
//                    }
//                }
            checkPercolates(index);
        }
    }

    private void checkPercolates(int index) {
        if (!percolates) {
            final boolean connectedToVirtualTop =
                    unionFind.connected(index, virtualTop);
            if (connectedToVirtualTop) {
                states[index] = true;
                for (int bottomRowIndex = (cellCount - N);
                     bottomRowIndex < cellCount; bottomRowIndex++) {
                    if (states[bottomRowIndex]) {
                        boolean connectedToBottomRow =
                                unionFind.connected(bottomRowIndex, index);
                        if (connectedToBottomRow) {
                            percolates = true;
                            break;
                        }
                    }
                }
            }
        }
    }

    private void unionIndexes(int adjacentIndex, int index) {
        if ((adjacentIndex != INVALID_INDEX) && (states[adjacentIndex])) {
            unionFind.union(adjacentIndex, index);
        }
    }

    /**
     * is site (row i, column j) open?
     *
     * @param i
     * @param j
     * @return
     */
    public boolean isOpen(int i, int j) {
        final int index = validateAndGetIndex(i, j);
        return (states[index]);
    }

    /**
     * is site (row i, column j) full?
     *
     * @param i
     * @param j
     * @return
     */
    public boolean isFull(int i, int j) {
        boolean full = false;
        final int index = validateAndGetIndex(i, j);
//        return (states[index] == State.FULL);
        boolean isOpen = states[index];
        if (isOpen) {
            full = unionFind.connected(index, virtualTop);
//            if (percolates) {
//                final int root = weightedQuickUnionUF.find(index);
//                full = (root == virtualTop);
//            }
        }
        return full;
    }

    /**
     * does the system percolate?
     *
     * @return
     */
    public boolean percolates() {
        return percolates;
    }

    private int validateAndGetIndex(int i, int j) {
        validate(i, j);
        return getIndex(i, j);
    }

    private boolean isTop(int i) {
        return i == 1;
    }

    private boolean isBottom(int i) {
        return i == N;
    }

    private int getTopIndex(int i, int j) {
        int calculatedIndex = INVALID_INDEX;
        if ((i > topRow)) {
            int temp = i - 1;
            calculatedIndex = getIndex(temp, j);
        }
        return calculatedIndex;
    }

    private int getBottomIndex(int i, int j) {
        int calculatedIndex = INVALID_INDEX;
        if ((i < bottomRow)) {
            int temp = i + 1;
            calculatedIndex = getIndex(temp, j);
        }
        return calculatedIndex;
    }

    private int getLeftIndex(int i, int j) {
        int calculatedIndex = INVALID_INDEX;
        if ((j > leftColumn)) {
            int temp = j - 1;
            calculatedIndex = getIndex(i, temp);
        }
        return calculatedIndex;
    }

    private int getRightIndex(int i, int j) {
        int calculatedIndex = INVALID_INDEX;
        if ((j < rightColumn)) {
            int temp = j + 1;
            calculatedIndex = getIndex(i, temp);
        }
        return calculatedIndex;
    }

    private void validate(int i, int j) {
        if (i < 1) {
            throw new IndexOutOfBoundsException("Invalid row " + i);
        }
        if (i > N) {
            throw new IndexOutOfBoundsException("Invalid row " + i);
        }
        if (j < 1) {
            throw new IndexOutOfBoundsException("Invalid column " + i);
        }
        if (j > N) {
            throw new IndexOutOfBoundsException("Invalid column " + i);
        }
    }

    private int getIndex(int i, int j) {
        int index = ((i - 1) * N) + (j - 1);
        return index;
    }

    private int getXCoordinate(int index) {
        int x = (index / N) + 1;
        return x;
    }

    private int getYCoordinate(int index) {
        int y = (index % N) + 1;
        return y;
    }
}
